
bmx-rjson

1. extract the archive

2. copy "twrc.mod" to "{BlitzMax}\mod\"
   where {BlitzMax} is the path to your installation directory for BlitzMax

3. run the following command:
   bmk.exe makemods twrc

 