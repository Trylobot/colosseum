Farseer Physics Engine for Blitzmax v1.0
------------------------------------------------
Released: 5/31/2008
Originally Created By: Jeff Weber [http://www.farseergames.com]
Ported To Blitzmax By: Alex Okafor [http://www.paradeofrain.com]

About
------
Farseer Physics Engine is a C# physics engine written by Jeff Weber [http://www.farseergames.com] on Microsoft's XNA Framework. I had prior experience using it in C# and liked the flexibility of being able to define just about any
shape for game levels and just use them without worrying about convexity/concavity constraints. With Jeff's permissions I proceeded to port the engine to Blitzmax. After some trial and error and langauge specific optimizations the engine is fairly stable and performs very closely if not the same to the original C# version.

The demo exe showcases most of the different usage scenarios and features of Farseer.


Installation
-------------
Installing the module:
- extract the module.zip file to "<Blitzmax Installationpath>/mod/".

Compiling the demo application from the mods folder:
- there is an example folder inside the farseerphysics.mod folder. Simply open the Main.bmx file in a blitzmax IDE and 
compile it to get the demo application up and running

Compiling the quickstart application from the mods folder:
- open the QuickStart.bmx file insider farseerphysics.mod/examples and compile it. It should bring up a minimal app showing some basic Farseer features.



History
--------

- 1.0
	- Finished porting all classes from C# to Blitzmax. Added several more demos showing how to use most of Farseer's features.
- 0.7.1
	- Initial Demo Release