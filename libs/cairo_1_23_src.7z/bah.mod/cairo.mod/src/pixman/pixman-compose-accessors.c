
#define PIXMAN_FB_ACCESSORS

#include "pixman-compose.c"
