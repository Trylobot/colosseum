Vertex.BNetEx v1.70 Beta 2

Copy the vertex.mod directory into _BMAXROOT_/mod/ and
use the ide for "build modules". Also you need to have MingW/GCC
installed(for windows.c, linux.c and bsd.c)

Before you use BNetEx please read the license agreements
in bnetex.bmx or in the doc files.

libiphlpapi.a is not written by the authors of BNetEx and
stands so not under the license of BNetEx.

--------------------------------------------------------------------

TNetwork.Ping, TNetwork.GetAdapterInfo, TUDPStream.SetBroadcast and
TUDPStream.GetBroadcast are betatesting.

Please make sure, you have root/administrator rights by testing
TNetwork.Ping and maybe TNetwork.GetAdapterInfo.